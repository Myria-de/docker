docker build --rm --tag firefox --file ./Firefox-Dockerfile .
