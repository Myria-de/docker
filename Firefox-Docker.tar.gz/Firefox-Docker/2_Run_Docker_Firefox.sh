docker run -d --restart always -p 5900:5900 -p 6099:6099 firefox

